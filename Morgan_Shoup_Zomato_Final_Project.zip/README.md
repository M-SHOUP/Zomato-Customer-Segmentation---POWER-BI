README.MD

# Project 7 Zomato Final Project 

README - Zomato Customer Analysis

Files included in this archive:
1. Zomato_Final_Report.pdf - Detailed summary of analysis, findings, and recommendations.
2. Morgan_Shoup_Final_Project.pdix
3. README.txt - This file, explaining file contents and project context.
4. PNG images of the three dashboards:
   - Customer Demographics.png
   - Customer Segments_Behavorial & Demographic Clustering.png
   - Customer Purchasing Behavior.png